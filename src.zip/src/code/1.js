import React from 'react'
import { BrowserRouter , Route , Switch} from 'react-router-dom'
import Nav from './2'
// BrowserRouter => 使用html5的history对象
// HashRouter => hash路由
// Route: 配置模板使用，常用属性有:
// 1.path: 指定路径
// 2.component: 指定路由匹配后需要渲染那个模板
//3.exact :是否启用严格校验

// Switch:性能优化  react-router组件内部默认使用for循环，不管有没有匹配中，都会循环所有的route组件，
//  使用switch以后，匹配中以后就会直接return，不会继续往下面遍历

//Redirect:   权限校验的时候使用
function Home() {
    return (<div>
        <h1>Home</h1>
    </div>)
}
function List() {
    return (<div>
        <h1>List</h1>
    </div>)
}

//用户登录界面
function Login() {
    return (<div>
        <h2>Login</h2>
        <button className="btn btn-primary">login</button>
    </div>)
}


function WrapCompoent() {
    return(<BrowserRouter>
        <Nav />
        {/* <Switch> */}
        <Route path="/home"  component={Home} />
        <Route path="/list" component={List}/>
        <Route path="/login" component={Login}/>
        {/* </Switch> */}
    </BrowserRouter>)
}

export default WrapCompoent