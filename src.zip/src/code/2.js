import React from 'react'
import { Link } from 'react-router-dom'
//Link : react-route包装后的react组件，使用该组件进行路由跳转
//属性to： 配置要 跳转的路径
function Nav() {
    return (<div className="container-fluid">

        <li><Link to="/home">Home</Link></li>
        <li><Link to="/list"> List</Link></li>
        <li><Link to="/login">user </Link></li>
        


    </div>)
}
export default Nav