import React,{Component} from 'react'

class Counter extends Component{
    state = {
        num :0,
    }
    
    incremanet = () =>{
        let {num} = this.state
        num++;
        
        this.setState({num})
    }
    //减法功能
    reduction = () =>{
        let {num} = this.state
        num--;
        // 设置num的最小值
        num = this.min(num)
        this.setState({num})
    }
    // 设置最小值
    min = num => (num <=0 ? 0 : num)
    render(){
        let {num} = this.state
        return (<div>
        <h1>{num}</h1>
        <button onClick={
            this.incremanet
        }>加加</button>
        <button onClick={
            this.reduction
        }>
        减减</button>
        </div>)
    }
}

export default Counter