import React,{Component} from 'react'
import {connect} from 'react-redux'
import actions from '../store/active'


class App extends Component{
    render(){
        console.log('this',this.props)
        let {tatal,increment,setData,delyAdd} = this.props
        return(
            <div>
                <p>total:{tatal}</p>
                <button onClick={increment}>increament</button>
                <button onClick={()=>setData(10)}>setData</button>
                <button onClick={delyAdd}>delyAdd</button>
            </div>
        )
    }
}

export default connect(state=> state,actions)(App)