import React,{Component} from 'react'

class Children extends Component{
    render(){
        return(
            <div>11111</div>
        )
    }
}

export default Children