import React,{Component} from 'react'

class Conter extends Component{
    render(){
        return(
            <div>11111</div>
        )
    }
}

export default Conter