import React from 'react'
import ReactDom  from 'react-dom'
import 'bootstrap/dist/css/bootstrap.css'
import App from './code2/app'
import {Provider} from 'react-redux'
import store from './store'
//引入自定义组件
// import Title from './code/1'


// 渲染页面
ReactDom.render(<div>
    <Provider store={store}>
    <App/>
    </Provider>
</div>, document.getElementById('root'))