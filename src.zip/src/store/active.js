import  * as actionType from './active-type'

export default {

        increment(){
        return {type:actionType.ADD}
    
        },
        setData(tatal){
        return {type:actionType.SET,payLoad:tatal}
        },
        delyAdd(){
            let timer = 0
            return(dispatch,getState)=>{
                clearImmediate(timer)
                timer= setTimeout(()=>{
                    dispatch({
                        type:actionType.SET,payLoad:100
                    })
                },1000)
            }
        }
}


