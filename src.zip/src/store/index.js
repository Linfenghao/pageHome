import {createStore,applyMiddleware} from 'redux'
import userReducer from './reducer'
import logger from 'redux-logger'
// import think from 'react-redux'
import thunk from 'redux-thunk'
let store = createStore(userReducer,applyMiddleware(thunk,logger))
export default store