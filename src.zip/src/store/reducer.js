import  * as actionType from './active-type'

let stateList ={
    tatal:0,
    list:[]
}
export default function(state = stateList,action){
    switch(action.type){
        case actionType.ADD:
            state={  
                ...state,
                tatal:state.tatal+1
            }
            return state
        case actionType.SET:
            state = {
                ...state,tatal:action.payLoad
            }
            return state
        default:
            return state
            break;
    }
}
